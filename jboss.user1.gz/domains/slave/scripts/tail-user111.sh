#!/bin/sh

su - jboss -c "cd /svc/was/user1/domains/slave; /svc/was/user1/domains/slave/tail-user111.sh"  
