#!/bin/sh

su - jboss -c "cd /svc/was/user1/domains/slave; /svc/was/user1/domains/slave/stop-user111.sh"  
