#!/bin/sh

su - jboss -c "cd /svc/was/user1/domains/slave; /svc/was/user1/domains/slave/start-user111.sh"  
