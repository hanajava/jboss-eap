KHAN JMX Monitoring
--------------------------------
